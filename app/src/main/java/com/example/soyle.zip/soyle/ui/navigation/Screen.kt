package com.example.soyle.ui.navigation

sealed class Screen(val route: String) {

    data object Home       : Screen("home")
    data object Onboarding : Screen("onboarding")
    data object Progress   : Screen("progress")
    data object Profile    : Screen("profile")

    data object Exercise : Screen("exercise/{phoneme}/{mode}") {
        fun createRoute(phoneme: String, mode: String) =
            "exercise/$phoneme/$mode"
    }

    data object Result : Screen("result/{score}/{phoneme}") {
        fun createRoute(score: Int, phoneme: String) =
            "result/$score/$phoneme"
    }
}